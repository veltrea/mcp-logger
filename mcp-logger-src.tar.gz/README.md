# MCP Logger

## 概要
本プロジェクトは、AI アシスタント（Claude, Gemini 等）が、自身の思考プロセスや対話イベントを Syslog として送信するための、MCP (Model Context Protocol) サーバー機能を提供します。
「Syslog サーバー」として動作するのではなく、既存の Syslog サーバー（例: `vlt-syslogd`）に対してログを送信する「クライアント機能」を AI に付与するものです。

人間用の CLI ロガーである `rust-logger` と共通のコアロジックを使用しながら、AI との対話に最適化されたインターフェースを提供します。

## 主な機能
- **Syslog メッセージ送信**: AI がサーバー名、ポート、ファシリティ、重要度、タグ、エンコーディング、メッセージを指定して Syslog を送信できます。
- **UTF-8 (BOMあり) 対応**: AI 解析に最適なエンコーディングをデフォルトで提供します。

## インストール
Rust の環境が必要です。

```bash
cargo build --release
```

## 使用方法 (CLI / MCP 兼用)

本ツールは「人間用の CLI」と「AI 用の MCP サーバー」の機能を併せ持っています。

### 1. 人間が CLI として使う (CLI モード)
ターミナルから直接ログを送信できます。

```bash
# 基本的な送信
mcp-logger send 192.168.1.40 "テストメッセージ"

# オプション指定
mcp-logger send 192.168.1.40 "エラー発生" --severity error --tag my-app
```

引数なしで `mcp-logger` を実行すると、MCP サーバーとしての設定方法（セットアップガイド）が表示されます。

### 2. AI アシスタントが使う (MCP モード)
`claude_desktop_config.json` 等に以下の設定を追加してください。

```json
{
  "mcpServers": {
    "mcp-logger": {
      "command": "/path/to/mcp-logger",
      "args": ["run-mcp"]
    }
  }
}
```

## AIアシスタント用ツール (MCP Tools)
本サーバーが AI に対して提供する機能です。

### `send-syslog`
AI が指定した Syslog サーバーにメッセージを送信します。

**引数:**
- `server` (string, 必須): 送信先 Syslog サーバーのホスト名または IP。
- `port` (number): ポート番号 (デフォルト: `514`)。
- `facility` (string): ファシリティ (例: `user`, `local0`)。デフォルトは `user`。
- `severity` (string): 重要度 (例: `info`, `error`)。デフォルトは `info`。
- `tag` (string): プログラム名 (タグ)。デフォルトは `mcp-syslog`。
- `encoding` (string): エンコーディング (例: `utf-8`, `shift_jis`)。デフォルトは `utf-8`。
- `message` (string, 必須): 送信するログメッセージ本文。
